<div class="copy_footer_wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="crm_left_footer_cont">
                    <p>{{ date('Y') }} © <span class="text-uppercase"> {{ env('SITE_NAME') }}</span>.</p>
                </div>
            </div>

        </div>
    </div>
</div>
