<!DOCTYPE html>
<html>
    <body>
        <div style="margin: 0; padding: 0; word-spacing: normal; background: ;">
            <div role="article" lang="en">
                <table role="presentation" style="width: 100%; border: none; border-spacing: 0;">
                    <tbody>
                        <tr>
                            <td align="center" style="padding: 0;">
                                <div style="width: 100%; max-width: 700px; margin-top: 50px;">
                                    <table class="m_-3852285001892450277main-wrap" role="presentation" style="width: 100%; border: none; border-spacing: 0; text-align: left; background-color: #ffffff; padding: 5px;">
                                        <tbody>
                                            <tr>
                                                <td style="padding: 10px 0; background-color: #ffffff;">
                                                    <div class="m_-3852285001892450277img-container">
                                                        <img style="width: 100px; height:40px"
                                                            src="{{ asset('images/logo.jpg') }}"
                                                            class="m_-3852285001892450277img CToWUd"
                                                            data-bit="iit"
                                                        />
                                                    </div>
                                                </td>
                                            </tr>