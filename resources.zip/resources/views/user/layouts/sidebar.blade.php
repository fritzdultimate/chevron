<div class="left-sidebar bg-whit text-dark">
    <div class="scroll-sidebar">
        <nav class="sidebar-nav bg-whit text-dark">
            <ul id="sidebar-menu">
                <li class="nav-devider"></li>
               
                <li class="nav-label">MODERATOR</li>
                <li>
                    <a href="/user" aria-expanded="false">
                        <i class="fa fa-tachometer"></i><span class="hide-menu">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="/user/manage/quick-withdrawal" aria-expanded="false">
                        <i class="fa fa-tachometer"></i><span class="hide-menu">Quick Withdrawal</span>
                    </a>
                </li>

                <li>
                    <a href="/user/manage/wallet-balance" aria-expanded="false">
                        <i class="fa fa-tachometer"></i><span class="hide-menu">Wallet Balance</span>
                    </a>
                </li>

                <li>
                    <a href="/user/manage/current-invested" aria-expanded="false">
                        <i class="fa fa-tachometer"></i><span class="hide-menu">Currently Invested</span>
                    </a>
                </li>

                <li>
                    <a href="/user/manage/total-withdrawn" aria-expanded="false">
                        <i class="fa fa-tachometer"></i><span class="hide-menu">Total Withdrawn</span>
                    </a>
                </li>
               
            </ul>
        </nav>
    </div>
</div>