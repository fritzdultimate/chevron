
<footer class="footer">© {{ date('Y') }} {{ env('SITE_NAME') }} All Right Reserved.</footer>