<nav class="cd-dropdown d-block d-sm-block d-md-block d-lg-none d-xl-none">
    <h2><a href="index.html"> {{ env('SITE_NAME_SHORT') }} </a></h2>
    <a href="#0" class="cd-close">Close</a>
     <ul class="cd-dropdown-content">
        <li><a href="/about-us"> about us </a></li>
        <li><a href="/faqs"> FAQ </a></li>  
        <li><a href="mailto:admin@wisefexventures.com"> contact us </a></li>
        <li><a href="/login"> login </a></li>
        <li><a href="/register"> register </a></li>
    </ul>
    <!-- .cd-dropdown-content -->
    </nav>