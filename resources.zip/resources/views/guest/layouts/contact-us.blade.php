<div class="contact-us" data-v-471b6f6c="">
    <div class="wrap" data-v-471b6f6c="">
        <div class="contact-us-con" data-v-471b6f6c="">
            <span data-v-471b6f6c="">Contact Us</span>
            <div class="dr" data-v-471b6f6c="">
                <div data-v-471b6f6c="">
                    <div class="d1" data-v-471b6f6c=""><img src="{{ asset('guest/img/icon4.76a22e8.svg') }}" alt="" data-v-471b6f6c="" /></div>
                    <div class="d2" data-v-471b6f6c="">
                        <p data-v-471b6f6c="">+1 7787443998</p>
                        <p class="p1" data-v-471b6f6c="">Multilingual 24x7 Professional Online Support</p>
                        <p class="p1" data-v-471b6f6c="">Australia</p>
                    </div>
                </div>
                <div data-v-471b6f6c="">
                    <div class="d3" data-v-471b6f6c=""><img src="{{ asset('guest/img/icon5.a56285b.svg') }}" alt="" data-v-471b6f6c="" /></div>
                    <div class="d4" data-v-471b6f6c="">
                        <p data-v-471b6f6c="">
                            Service &amp; Support: support@ {{ env('APP_NAME') }}
                        </p>
                        <p data-v-471b6f6c="">Business Enquiry:</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>