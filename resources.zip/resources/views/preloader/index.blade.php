<div id="preloader" style="background: black">
    <div id="status">
        <img src="/images/wloader.jpeg" id="preloader_image" alt="loader">
    </div>
</div>