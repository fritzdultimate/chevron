
@include('emails.layouts.header')
    @yield('content')
@include('emails.layouts.footer')