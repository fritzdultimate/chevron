
    <div class="footer_main_wrapper index2_footer_wrapper float_left">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12">
                    <div class="wrapper_second_useful wrapper_second_useful_2">
                        <h4>contact  us</h4>

                        <ul>
                            <li>
                                <h1>+800 568 322</h1></li>
                            <li><a href="#"><i class="flaticon-mail"></i>SiteName@example.com</a>
                            </li>
                            <li><a href="#"><i class="flaticon-language"></i>www.example.com</a>
                            </li>

                            <li><a href=""><i class="flaticon-placeholder"></i>110, B Street Kalani Bagh Dewas, Madhya Pradesh, INDIA #455001</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                    <div class="copyright_wrapper float_left">
                        <div class="copyright">
                            <p>Copyright <i class="far fa-copyright"></i> {{ date('Y') }} <a href="/"> {{ env('SITE_NAME') }}</a>. all right reserved </p>
                        </div>
                        <div class="social_link_foter">

                            <ul>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <script src="{{ asset('js/jquery-3.3.1.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/modernizr.js') }}"></script>
    <script src="{{ asset('js/jquery.menu-aim.js') }}"></script>
    <script src="{{ asset('js/plugin.js') }}"></script>
    <script src="{{ asset('js/jquery.countTo.js') }}"></script>
	<script src="{{ asset('js/dropify.min.js') }}"></script>
	<script src="{{ asset('js/datatables.js') }}"></script>
    <script src="{{ asset('js/jquery.nice-select.min.js') }}"></script>
    <script src="{{ asset('js/jquery.inview.min.js') }}"></script>
    <script src="{{ asset('js/jquery.magnific-popup.js') }}"></script>
    <script src="{{ asset('js/owl.carousel.js') }}"></script>
    <script src="{{ asset('js/calculator.js') }}"></script>
    <script src="{{ asset('js/custom.js') }}"></script>
    <script src="{{ asset('js/fn.js') }}"></script>