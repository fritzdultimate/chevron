<script src="<?php echo e(asset('assets/js/lib/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/modal/jquery.modal.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/sidebarmenu.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lib/sticky-kit-master/dist/sticky-kit.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatable/datatables.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('.select-2').select2();
    });
</script><?php /**PATH C:\laragon\www\chevron\resources\views/admin/layouts/general-scripts.blade.php ENDPATH**/ ?>