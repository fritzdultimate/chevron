<?php if($errors->any()): ?>
    <div class="alert alert-danger p-2 small">
            <?php echo e($errors->all()[0]); ?>

    </div>
<?php elseif(session('error')): ?>
    <div class="alert alert-danger p-2 small">
        <span class="alert-text">
            <?php echo e(session('error')); ?>

        </span>
    </div>
<?php elseif(session('success')): ?>
    <div class="alert alert-success p-2 small">
        <span class="alert-text">
            <?php echo e(session('success')); ?>

        </span>
    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\chevron\resources\views/user/layouts/errors.blade.php ENDPATH**/ ?>