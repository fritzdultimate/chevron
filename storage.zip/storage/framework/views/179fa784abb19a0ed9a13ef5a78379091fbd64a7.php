<div class="refer-right">
    <div class="referbg">
        <div class="slide_right">  
            <div class="login">  

                <style>
                    ::placeholder { 

                        color: #fff;
                        opacity: 1; 
                    }
                </style>  

                <script language=javascript>
                function checkform() {
                if (document.mainform.username.value=='') {
                    alert("Please type your username!");
                    document.mainform.username.focus();
                    return false;
                }
                if (document.mainform.password.value=='') {
                    alert("Please type your password!");
                    document.mainform.password.focus();
                    return false;
                }
                return true;
                }
                </script>
                <div class="login-title">
                    <h3>Log In Acount</h3>
                </div>  

                <form class="page-form login-form">
                    <table cellspacing=0 cellpadding=8 border=0 style="color:#555;    line-height: 52px;    margin-left: 25px;">
                        <tr>
                            <td>
                                <div class="icon-2">
                                    <i class="fa fa-user" style="margin: 7px 0px 0px 10px;"></i> 
                                </div>
                                <input required name="login" value='' type="text" class="inpts-2" size=30 autofocus="autofocus" placeholder="Username Or Email">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="icon-2">
                                    <i class="fa fa-key" style="margin: 7px 0px 0px 10px;"></i> 
                                </div>
                                <input required type="password" name="password" class="inpts-2" size=30 placeholder="Password *">
                            </td>
                        </tr>
                    </table>  
                    

                    <div>
                        <a href="/login" class="btn btn-warning w-100 input-rounded sbmt-2" type="submit">
                            <span class="form-loading d-none px-5">
                                <i class="fa fa-sync fa-spin"></i>
                            </span>
                            <span class='submit-text'> 
                                Login
                            </span>
                        </a>
                    </div>
                </form>

                <p style=" margin-top: 5px;"><span><a href="/forgot-password">forgot your Password?</a></span></p>
            </div><!--login-->
        </div>
    </div>
    
    <div class="refer-but">
        <a href="/register"> 
            <img src="images/reg-img.png"> 
            Register now
        </a>
    </div>
</div>
<script src="/assets/js/v/jquery.bundle2453.js?ver=1"></script>
<script src="/assets/js/v/scripts2453.js?ver=1"></script>
<script src="/assets/js/v/charts2453.js?ver=1"></script>
<script src="/assets/js/v/footer-plugins.js?ref=4"></script>
<script src="<?php echo e(asset('dash/plugins/lobibox/js/lobibox.js')); ?>"></script>
<script src="<?php echo e(asset('dash/js/fn.js')); ?>"></script>
<script src="<?php echo e(asset('dash/js/login.js')); ?>"></script>
<?php /**PATH C:\laragon\www\sinopecstocks\resources\views/visitor/layouts/login-form.blade.php ENDPATH**/ ?>