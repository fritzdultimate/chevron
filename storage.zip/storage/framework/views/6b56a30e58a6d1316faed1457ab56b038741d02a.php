        <div class="nk-footer nk-footer-fluid bg-lighter">
            <div class="container-xl wide-lg">
                <div class="nk-footer-wrap">
                    <div class="nk-footer-copyright"> &copy; 2024 <?php echo e(env('SITE_NAME')); ?>. Designed by <a href="https://<?php echo e(env('APP_NAME')); ?>.org/" target="_blank"><?php echo e(env('SITE_NAME')); ?> team</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
    var _smartsupp = _smartsupp || {};
    _smartsupp.key = '50dbfbd22632ba5eb4899b75a3980efcd0fd771b';
    window.smartsupp||(function(d) {
      var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
      s=d.getElementsByTagName('script')[0];c=d.createElement('script');
      c.type='text/javascript';c.charset='utf-8';c.async=true;
      c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
    })(document);
    </script>
    <noscript> Powered by <a href=“https://www.smartsupp.com” target=“_blank”>Smartsupp</a></noscript>
    
    
    
    
    <script src="<?php echo e(asset('_assets/js/bundleee9a.js?ver=3.2.2')); ?>"></script>
    <script src="<?php echo e(asset('_assets/js/scriptsee9a.js?ver=3.2.2')); ?>"></script>
    <script src="<?php echo e(asset('_assets/js/demo-settingsee9a.js?ver=3.2.2')); ?>"></script>
    <script src="<?php echo e(asset('_assets/js/charts/chart-investee9a.js?ver=3.2.2')); ?>"></script>


  </body>
</html>
<?php /**PATH C:\Users\pc\Documents\Projects\sinopecstocks\resources\views/user_new/layouts/footer.blade.php ENDPATH**/ ?>