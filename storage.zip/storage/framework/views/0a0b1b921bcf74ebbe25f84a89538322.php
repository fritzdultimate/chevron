        <div class="nk-footer nk-footer-fluid bg-lighter">
            <div class="container-xl wide-lg">
                <div class="nk-footer-wrap">
                    <div class="nk-footer-copyright"> &copy; 2024 <?php echo e(env('SITE_NAME')); ?>. Designed by <a href="https://<?php echo e(env('APP_NAME')); ?>.org/" target="_blank"><?php echo e(env('SITE_NAME')); ?> team</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    <noscript> Powered by <a href=“https://www.smartsupp.com” target=“_blank”>Smartsupp</a></noscript>
    
    
    
    
    <script src="<?php echo e(asset('_assets/js/bundleee9a.js?ver=3.2.2')); ?>"></script>
    <script src="<?php echo e(asset('_assets/js/scriptsee9a.js?ver=3.2.2')); ?>"></script>
    <script src="<?php echo e(asset('_assets/js/demo-settingsee9a.js?ver=3.2.2')); ?>"></script>
    <script src="<?php echo e(asset('_assets/js/charts/chart-investee9a.js?ver=3.2.2')); ?>"></script>


  </body>
</html>
<?php /**PATH C:\laragon\www\chevron\resources\views/user_new/layouts/footer.blade.php ENDPATH**/ ?>