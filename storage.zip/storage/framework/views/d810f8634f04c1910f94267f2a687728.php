<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main-wrapper">
            <?php echo $__env->make('admin.layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-wrapper">
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h3 class="text-dark">Child Plans</h3>
                    </div>
                    <div class="col-md-7 align-self-center">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Admin</a></li>
                            <li class="breadcrumb-item active">Child Plans</li>
                        </ol>
                    </div>
                </div>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <?php echo $__env->make('admin.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6>
                                        <button class="btn btn-rounded btn-primary add-plan">Add Child Plan</button>
                                    </div>
                                    <div class="table-responsive m-t-10">
                                        <table id="record-table" class="display record-table record-export nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Parent Plan</th>
                                                    <th>minimum amount ($)</th>
                                                    <th>maximum amount ($)</th>
                                                    <th>interest rate (%)</th>
                                                    <th>referral bonus (%)</th>
                                                    <th>duration (days)</th>
                                                    <th>Active</th>
                                                    <th>action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $child_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child_plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="background_white">
                                                    <td>
                                                        <?php echo e($child_plan['name']); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($child_plan->parent_plan ? $child_plan->parent_plan->name : ''); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($child_plan['minimum_amount']); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($child_plan['maximum_amount']); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($child_plan['interest_rate']); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($child_plan['referral_bonus']); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($child_plan['duration']); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($child_plan['active'] ? 'True' : 'False'); ?>

                                                    </td>
                                                    <td class="text-center">
                                                        <div class="dropdown">
                                                            <button class="btn btn-outline-dark" type="button" data-toggle="dropdown">
                                                                <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                                            </button>
                                                            <div class="dropdown-menu">
                                                                <a data-action="edit" 
                                                                data-name="<?php echo e($child_plan['name']); ?>" data-minimum_amount="<?php echo e($child_plan['minimum_amount']); ?>" 
                                                                data-maximum_amount="<?php echo e($child_plan['maximum_amount']); ?>" data-referral_bonus="<?php echo e($child_plan['referral_bonus']); ?>" 
                                                                data-interest_rate="<?php echo e($child_plan['interest_rate']); ?>" data-duration="<?php echo e($child_plan['duration']); ?>" data-id="<?php echo e($child_plan['id']); ?>" 
                                                                data-parent_id="<?php echo e($child_plan['parent_investment_plan_id']); ?>"  class="action-link dropdown-item" href="#">Edit</a>
                                                                <form action="" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="id" value="<?php echo e($child_plan['id']); ?>">
                                                                    <input type="hidden" name="action" value="delete">
                                                                    <button type="submit" data-action="delete" data-id="<?php echo e($child_plan['id']); ?>" class="dropdown-item" href="#">Delete</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="modal" id="plan-modal">
            <form class="page-form plan-form" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group icon_form comments_form">
                    <label class="text-dark">Parent Plan</label>
                    <select class="w-100 form-control bg-light text-dark" name="parent_id" id="parent_id">
                        <?php $__currentLoopData = $parent_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent_plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($parent_plan['id']); ?>"> <?php echo e($parent_plan['name']); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group icon_form comments_form">
                    <label class="text-dark">Plan Name</label>
                    <input required type="text" class="form-control bg-light text-dark require" name="name" placeholder="Enter Plan Name">
                </div>
                <div class="form-group icon_form comments_form">
                    <label class="text-dark">Minimum Amount($)</label>
                    <input required type="number" class="form-control bg-light text-dark require" name="minimum_amount" placeholder="Enter Plan Minimum Amount">
                </div>
                <div class="form-group icon_form comments_form">
                    <label class="text-dark">Maximum Amount($)</label>
                    <input required type="number" class="form-control bg-light text-dark require" name="maximum_amount" placeholder="Enter Plan Maximum Amount">
                </div>
                <div class="form-group icon_form comments_form">
                    <label class="text-dark">Duration(days)</label>
                    <input required type="number" class="form-control bg-light text-dark require" name="duration" placeholder="Enter Plan Duration in days">
                </div>
                <div class="form-group icon_form comments_form">
                    <label class="text-dark">Interest Rate(%)</label>
                    <input required type="number" class="form-control bg-light text-dark require" name="interest_rate" placeholder="Enter Plan Interest">
                </div>
                <div class="form-group icon_form comments_form">
                    <label class="text-dark">Referral Bonus(%)</label>
                    <input required type="number" class="form-control bg-light text-dark require" name="referral_bonus" placeholder="Enter Plan Referral Bonus">
                </div>
                <div>
                    <input type="hidden" name="id">
                    <button type="submit" class="btn btn-primary rounded-btn w-100">
                        <span class="form-loading d-none px-5">
                            <i class="fa fa-sync fa-spin"></i>
                        </span>
                        <span class='submit-text'>
                            Submit
                        </span>
                    </button>
                </div>
            </form>
        </div>
        <?php echo $__env->make('admin.layouts.general-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="<?php echo e(asset('assets/js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/lib/datatables/cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/custom.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/fn.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/admin.child-plan.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\laragon\www\chevron\resources\views/admin/child-plan.blade.php ENDPATH**/ ?>