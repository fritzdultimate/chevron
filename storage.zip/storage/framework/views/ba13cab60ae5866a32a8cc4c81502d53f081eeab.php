<div class="scroll-top" style="display: ;" data-v-02314767="">
    <div class="wrap" data-v-02314767="">
        <div class="flex_sb_cen" data-v-02314767="">
            <div class="Breadcrumb" data-v-02314767=""><div aria-label="Breadcrumb" role="navigation" class="el-breadcrumb"></div></div>
            <div class="flex_cen_cen scroll_top_btn_click" data-v-02314767="">
                <span data-v-02314767="">Scroll Back To Top</span> <span class="st flex_cen_cen scroll_top_btn_click" data-v-02314767=""><i class="iconfont iconscroll-top" data-v-02314767=""></i></span>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\pc\Documents\Projects\sinopecstocks\resources\views/guest/layouts/scroll-to-top.blade.php ENDPATH**/ ?>