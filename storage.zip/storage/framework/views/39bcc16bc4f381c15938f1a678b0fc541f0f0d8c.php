<?php echo $__env->make('visitor.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('visitor.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
* {
    font-size: 30px;
}
</style>

    <!-------------- about --------------->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
    <script  src="images/js/simpleslider.js"></script>

    <div id="wrapper" class="banner-bg">
        <div class="wrap">
            <div class="banner">
                <div class="simple-slider">
                    <img src="images/slide0.jpg" class="single-slide animate-left"/>
                    <img src="images/slide1.jpg" class="single-slide animate-left"/>
                    <img src="images/slide8.jpg" class="single-slide animate-left"/>
                    <img src="images/slide33.jpg" class="single-slide animate-left"/>
                    <img src="images/slide4.jpg" class="single-slide animate-left"/>
                    <img src="images/slide7.jpg" class="single-slide animate-left"/>
                    <img src="images/slide6.jpg" class="single-slide animate-right"/>
                    <img src="images/slide5.jpg" class="single-slide animate-left"/>
                    <img src="images/slide2.jpg" class="single-slide animate-left"/>
                    <img src="images/slide11.jpg" class="single-slide animate-left"/>
                    <img src="<?php echo e(asset('')); ?>" class="single-slide animate-left"/>
                    <button class="slider-button slider-left">&#10094;</button>
                    <button class="slider-button slider-right">&#10095;</button>
                </div>
            </div>
        </div>
    </div><div class="clear"></div>




    <div id="wrapper" class="plan-bg">
        <div class="wrap">
            <div class="plan">
            
                <div class="plan-head">
                    <h2 class="line">
                        <span>EXCLUSIVE OIL AND GAS CROWDFUNDING INVESTMENT DEALS (ROI) </span>
                    </h2>
                </div>
                
                <?php echo $__env->make('visitor.layouts.plans-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
            </div>
        </div>
    </div><div class="clear"></div>



    <div id="wrapper" class="refer-bg">
        <div class="wrap">
            <div class="refer">
                <div class="refer-left">
                    <div class="refer-head">
                        <h2 class="line">
                            <span>ABOUT OUR OIL AND GAS CROWDFUNDING PROJECT</span>
                        </h2>
                        <p>
                            <img style="width: 650px; height: 500px; padding:0px;margin-left:18px" src="images/success1.jpg">
                            <br><br>
                            <?php echo e(env("SITE_NAME")); ?> is an international energy and chemical company that has achieved upstream, midstream and downstream integration, has been ranked among the top 3 in the Fortune Global 500 for many consecutive years, with a wide range of products and services, its operations covering more than 70 countries and regions in the world. We aim to change the archaic ways of investing in oil and gas.Through our Crowdfunding platform, so that an average investor will be able to access opportunities perfect for generating income through an international oil and gas investment and operation.
                        </p>                 
                        <p>
                            <img style="width: 650px; height: 500px; padding:0px;margin-left:18px" src="images/success2.jpg"><br><br><?php echo e(env("SITE_NAME")); ?> disinter-mediates this flawed investment model, by providing a system of project designed to generate cash flow returns from wellhead directly back to investors. We put together a powerful team to bring equity crowdfunding into oil and gas sector with a disruptive business model. Our platform synchronizes fintech, crowdfunding and deep industry experience. We develop environmental, social and governance standards to ensure that investors on our platform benefit from responsible placement of capital and overall company culture that fosters an inclusive environment.
                        </p>

                        <p>
                            <img style="width: 650px; height: 500px; padding:0px;margin-left:18px" src="images/success3.jpg"><br><br>
                            Our buisness model generates revenue through each investment deal(ROI) that is funded through this platform. Each investment deal(ROI) comes with management charge and carried interest structure. Making is easy to access, choose, invest and collect returns, by leveraging our team experience, Investors can select an investment deal(ROI) with defined targets which comes with a low relative risk profile. Investors new to oil and gas investment don't have to really understand specifics about the industry in order to generate cash flow. Oil and gas deals can be complex but our experienced team helps in determining a suitable structure of deals to make sure that percentages are fair so that our investors and operators are financially motivated to succeed.
                        </p>

                    </div>
                    
                    <div class="refer-com">
                        <div class="refer-com1">
                            <div class="refer-img">
                                <img src="images/ref-img.png">
                            </div>
                            
                            <div class="refer-cont">
                                <b> 5% </b> &nbsp;&nbsp; <span> Referral commision<br></span>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
                <?php echo $__env->make('visitor.layouts.login-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>
    <div class="clear"></div>



    <div id="wrapper" class="advan-bg">
        <div class="wrap">
            <div class="advan">
                <div class="advan-head">
                    <h2 class="line">
                        <span> <b> WHY <?php echo e(env("SITE_NAME")); ?> ?</span><br><br>
                    </h2>
                    <h1 style="font-family:Helvetica;text-align:center;color:#ffffff;">
                        Some of the greatest fortunes in the world was built from this project
                    </h1>
                    <br><br>
                    <img style="width: 100%; height: 350px; padding:0px;" src="images/success2.png">
                </div>
                <div class="advanbg">
                    <div class="advanbg1">
                        <div class="advan-img"><img src="images/min1.png"><p> <span> IN CONTEXT </span></p></div>
                        <div class="advan-cont">
                            <p><span>18th </span> In proven crude oil reserves, as country (2018 -January)</p>
                            <p><span>39th </span> In proven reserves of natural gas, as country (2018 -January)</p>
                            <p><span>12th </span> Producer of crude oil in the world, as country (2017)</p>
                            <p><span>16th </span> In natural gas production, as country (2017)</p>
                            <p><span>14th </span>  In primary distillation capacity (2016)</p>
                            <p class="cont-line">For further information: 2017 Statistical Yearbook (Information available only in Spanish)</p>
                        </div>
                    </div>
                    
                    <div class="advanbg1">
                        <div class="advan-img1"><img src="images/min2.png"><p> <span> Value Chain </span></p></div>
                        <div class="advan-cont1">
                            <p class="advan-text"><span>Upstream</span></p>
                            <p class="advan-text"><img src="images/min-line1.png"></p><br>
                            <p class="advan-text"><span>Downstream</span></p>
                            <p class="advan-text"><img src="images/min-line2.png"></p><br>
                            <p class="advan-text"><span>Logistic</span></p>
                            <p class="advan-text"><img src="images/min-line1.png"></p><br>
                            <p class="advan-text"><span>Commercialization</span></p>
                            <p class="advan-text"><img src="images/min-line2.png"></p><br>
                            <p class="cont-line">For further information:<br>Our business</p>
                        </div>
                    </div>
                    
                    <div class="advanbg1">
                        <div class="advan-img"><img src="images/min3.png"><p> <span> HIGH PERFORMANCE </span></p></div>
                        <div class="advan-cont">
                            <p>High performance yield with excellent return on capital investment with short pay-back periods</p>
                            <p>Low Risk Investment is achieved due to strict selection of proposal by our experienced team</p>
                            <p>We have assembled a multidisciplinary team capable of managing investment deals to adapted to our clients need.</p>
                            <p>We promote and support new ideas in the oil industry. We are a platform that finances oil projects through private investors efforts.</p>
                        </div>
                    </div>
                    
                    <div class="advanbg1">
                        <div class="advan-img1"><img src="images/min4.png"><p> <span> Sustainability </span></p></div>
                        <div class="advan-cont">
                            <p>Business responsibility and transparency on the management of financial resources is key to maximize profits for the company.</p>
                            <p>We carefully examine and identify the opportunities to determine which are the most beneficial for our clients</p>
                            <p>We promote and support new ideas in the oil industry. We are a platform that finances oil projects through private investors efforts</p>
                            <p>We strategically provide a positive experience for those investors – experienced and beginners </p>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="clear"></div>




    <div id="wrapper" class="terms-bg">
        <div class="wrap">
            <div class="terms">
            
                <div class="terms-head">
                    <h2 class="line">
                        <span> WHAT WE OFFER </span><br>
                    </h2>
                </div>
                
                <div class="termsbg">
                    <div class="termsbg1">
                        <div class="terms1">
                            <img src="images/terms1.png">
                            <p>EASY TO USE INVESTMENT PLATFORM.</p>
                        </div>
                    </div>
                    
                    <div class="termsbg1">
                        <div class="terms1">
                            <img src="images/terms2.png" style="width: 50%;">
                            <p>HIGH POTENTIAL RETURN </p>
                        </div>
                    </div>
                    
                    <div class="termsbg1">
                        <div class="terms1">
                            <img src="images/terms3.png">
                            <p>VAST INVESTMENT DEALS(ROI) </p>
                        </div>
                    </div>
                    
                    <div class="termsbg1">
                        <div class="terms1">
                            <img src="images/terms4.png">
                            <p>NO HIDDEN CHARGES <br> OR WITHDRAWAL FEES</p>
                        </div>
                    </div>
                    
                    <div class="termsbg1">
                        <div class="terms1">
                            <img src="images/terms5.png">
                            <p>HIGHLY SECURED WITH <br> GUARANTEED SAFETY OF <br> PERSONAL DATA AND FUNDS</p>
                        </div>
                    </div>
                    
                    <div class="termsbg1">
                        <div class="terms1">
                            <img src="images/terms6.png">
                            <p>CRYPTOCURRENCY GATEWAY ACCEPTED</p>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div><div class="clear"></div>




    <div id="wrapper" class="test-bg d-none" style="display: none">
        <div class="wrap">
            <div class="test">
            
                <div class="test-head">
                    <h2 class="line">
                        <span> Investors testimonials </span>
                    </h2>
                </div>
                
                <div class="testbg">
                    <div class="testbg1">
                        <div class="test-star">
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>

                        </div>
                        <p><a href="/"><img src="images/test1.png"></a></p>
                        <div class="test-cont">
                            <p>“I recieved my investment fund update this morning--and holy cow--you guys are doing a great job! I'm kicking myself for not putting more into this deal. I won't make the same mistake next time! Please keep me in mind for future opportunities...I'd love to invest more with Praxis!"</p>
                        </div>
                        
                        <div class="test-author" style="    padding:50px 0px 20px 15px;">
                            <h2>Becky Hallam</h2>
                            <p>Investor in Tennessee</p>
                        </div>
                    </div>
                    
                    <div class="testbg1">
                        <div class="test-star">
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                        </div>
                        <p><a href="/"><img src="images/test2.png"></a></p>
                        <div class="test-cont">
                            <p>"I wanted to let you know that we were able to swing by and look at the project in person.  Loved it!  The design is really attractive and the location is ideal. We are very glad that we invested in this project. Thanks for sourcing such a great opportunity and let us know if there is ever a future capital raise on this project."</p>
                        </div>
                        
                        <div class="test-author">
                            <h2>Jane Caro</h2>
                            <p>INVESTOR IN CALIFORNIA</p>
                        </div>
                    </div>
                    
                    <div class="testbg1">
                        <div class="test-star">
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                        </div>
                        <p><a href="/"><img src="images/test3.png"></a></p>
                        <div class="test-cont">
                            <p>"The executive summary, as well as the entire business plan, is one of the best I have ever read...a tightly written, well expressed and complete recitation of all the key facts and data that an investor could want..."</p>
                        </div>
                        
                        <div class="test-author" style="    padding:100px 0px 20px 15px;">
                            <h2>Nelson Baremore</h2>
                            <p>PRESIDENT, INVESTMENT CO IN ILLIONOIS</p>
                        </div>
                    </div>
                    
                    <div class="testbg1">
                        <div class="test-star">
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                        </div>
                                                <p><a href="/"><img src="images/test4.png"></a></p>
                        <div class="test-cont">
                            <p>In the investment world, and business in general, an individual’s or company’s character is of the utmost importance. It is due to this trust and faith (plus the financial and deep track record) that I hold the Praxis team in high regard. I have personally invested with Praxis and have also referred a number of clients who, upon doing their own due diligence, have invested with Praxis as well.</p>
                        </div>
                        
                        <div class="test-author">
                            <h2>Touqeer Khan</h2>
                            <p>Investor in Pakistan</p>
                        </div>
                    </div>	
                </div>
                
            </div>
        </div>
    </div>
    <!----------- stat -------------------->


    <!----------- footer ------------->
    <div id="wrapper" class="terms-bg" style="width: 100%; text-align: center">
        <p style="color:#FFFFFF"><b>Note:</b> <?php echo e(env("SITE_NAME")); ?> offers direct and alternative  oil and gas investment opportunities that  enable investors to participate in the potential cash flow and the unique tax benefits associated with oil and gas investments. There are significant risks associated with investing in oil and gas offerings. The information contained in this website is for informational purposes only and is not a solicitation to buy or sell any securities. Information on this site is not intended to be used as investment or tax advice. Consult your investment advisor or tax advisor concerning the current tax laws and effects on your personal tax situation.</p>
        <p style="color:#FFFFFF"><b>Disclaimer:</b>Nothing published by <?php echo e(env("SITE_NAME")); ?> should be considered personalized investment or tax advice. There are significant risks associated with investing in Oil and Gas Ventures. This is not a solicitation to buy or an offer to sell any securities. Any such solicitation or offer will only be made through a Private Placement Memorandum in accordance with Regulation D Rule 506. A thorough discussion of Tax Benefits and Risk Factors associated with this kind of investment are contained within the Private Placement Memorandum.</p>
        <p style="color:#FFFFFF;text-align:center;"><b>&#169;2004 - <?php echo e(date('Y')); ?> <?php echo e(env("SITE_NAME")); ?> Investment All Right Reserved</b></p>
        <div class="clear"> </div>
        <!--<div class="clear"></div>-->
    </div><div class="clear"> </div>
    <!----------- footer ------------->
    

    <!-- Smartsupp Live Chat script -->
<script type="text/javascript">
    var _smartsupp = _smartsupp || {};
    _smartsupp.key = '50dbfbd22632ba5eb4899b75a3980efcd0fd771b';
    window.smartsupp||(function(d) {
      var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
      s=d.getElementsByTagName('script')[0];c=d.createElement('script');
      c.type='text/javascript';c.charset='utf-8';c.async=true;
      c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
    })(document);
    </script>
    <noscript> Powered by <a href=“https://www.smartsupp.com” target=“_blank”>Smartsupp</a></noscript>

    </body>
</html><?php /**PATH C:\laragon\www\sinopecstocks\resources\views/guest/new_index.blade.php ENDPATH**/ ?>