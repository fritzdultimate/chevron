<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="wb:op" content="8b6e6e4402c7031de4fa53272335907b"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <!-- Primary Meta Tags -->
        <title>Oil and Gas Crowdfunding Investment Opportunity.</title>
        <meta name="title" content="Oil and Gas Crowdfunding Investment Opportunity.">
        <!--<meta name="viewport" content="width=device-width, initial-scale=0.8, user-scalable=1">-->
        <meta name="description" content="<?php echo e(env("SITE_NAME")); ?> disintermediates this flawed investment model, by providing a platform of projects designed to generate cash flow returns from the wellhead directly back to investors. We give you a platform for direct access to oil and gas cash flow returns. Our projects generate positive cash flow returns.">
    
        <!-- Open Graph / Facebook -->
        <meta property="og:type" content="website">
        <meta property="og:url" content="/">
        <meta property="og:title" content="Oil and Gas Crowdfunding Investment Opportunity.">
        <meta property="og:description" content="<?php echo e(env("SITE_NAME")); ?> disintermediates this flawed investment model, by providing a platform of projects designed to generate cash flow returns from the wellhead directly back to investors. We give you a platform for direct access to oil and gas cash flow returns. Our projects generate positive cash flow returns.">
        <meta property="og:image" content="images/tag1.jpg">
    
        <!-- Twitter -->
        <meta property="twitter:card" content="summary_large_image">
        <meta property="twitter:url" content="/">
        <meta property="twitter:title" content="Oil and Gas Crowdfunding Investment Opportunity.">
        <meta property="twitter:description" content="<?php echo e(env("SITE_NAME")); ?> disintermediates this flawed investment model, by providing a platform of projects designed to generate cash flow returns from the wellhead directly back to investors. We give you a platform for direct access to oil and gas cash flow returns. Our projects generate positive cash flow returns.">
        <meta property="twitter:image" content="images/tag1.jpg">
        <link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,500,700,500italic,700italic' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Ubuntu:400,300italic,300,400italic,500,700,500italic,700italic' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo e(asset('css/tabsstyle.html')); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo e(asset('css/faqstyle.css')); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo e(asset('css/transtabstyle.css')); ?>" type="text/css" />
        <link rel="shortcut icon" type="image/png" href="images/favicon.png"/>
        <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.html')); ?>" type="text/css"/>
        <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>" type="text/css"/>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>" type="text/css"/>
        <link rel="stylesheet" href="<?php echo e(asset('css/tabcontent.css')); ?>" type="text/css"/>
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Muli:200,300,400,600,700,800,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:100,300,400,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Palanquin+Dark:400,500,600,700" rel="stylesheet">
    
        <link rel="stylesheet" href="<?php echo e(asset('css/letterdrop.html')); ?>" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Expletus+Sans:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:100,100i,300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700" rel="stylesheet">
    
        <link href="https://fonts.googleapis.com/css?family=Teko:300,400,500,600,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700" rel="stylesheet">
    
        <link href="https://fonts.googleapis.com/css?family=Rajdhani:300,400,500,600,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Saira+Semi+Condensed:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    
        <link rel="stylesheet" href="<?php echo e(asset('css/simpleslider.css')); ?>" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dash/plugins/lobibox/css/lobibox.min.css?ref=0')); ?>">
        <!--- banner tab script --->
    
        <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <script src="<?php echo e(asset('images/js/prefixfree.min.js')); ?>"></script>
    
        <!--- banner tab script --->
    
        <!---- calc script --->
    
        <script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js"></script>
        <script type="text/javascript" src="<?php echo e(asset('images/js/calcs.js')); ?>"></script>
    
        <!---- calc script --->
    
        <!---- Wow script --->
    
    
    
        <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/0.1.12/wow.min.js"></script>
        <script src="<?php echo e(asset('images/js/wow.js')); ?>"></script>
    
    
    
    
        <script type="text/javascript" src="<?php echo e(asset('images/js/tabcontent.js')); ?>"></script>
    
    
    
    
        <script>
    
            new WOW().init();
    
            </script>
    
    
    
        <!---- Wow script --->
    
    </head><?php /**PATH C:\Users\pc\Documents\Projects\sinopecstocks\resources\views/visitor/layouts/head.blade.php ENDPATH**/ ?>