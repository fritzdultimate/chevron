<div class="planbg">
    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="<?php echo e(($plan->name == "GAS") ? "planbg1" : ( ($plan->name == "PETROLEUM") ? "planbg2" : ( ($plan->name == "ENERGY") ? "planbg3" : ($plan->name == "AGRO CHEMICAL" ? "planbg4" : "planbg5")))); ?>">
        <div class="plan-head1"><?php echo e($plan->name); ?></div>
        <div class="plan-per"><?php echo e(round($plan['interest_rate']) * $plan['duration']); ?>%</div>
        <div class="plan-day">After <?php echo e($plan['duration']); ?> day(s)</div>
        <div class="plan-min"><img src="images/tik.png"> Min : $<?php echo e(round($plan['minimum_amount'])); ?></div>
        <div class="plan-max"><img src="images/tik.png"> Max : $<?php echo e(round($plan['maximum_amount'])); ?></div> 
        <div class="plan-but">
            <a href="/signup">INVEST</a>
        </div>                	
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laragon\www\sinopecstocks\resources\views/visitor/layouts/plans-template.blade.php ENDPATH**/ ?>