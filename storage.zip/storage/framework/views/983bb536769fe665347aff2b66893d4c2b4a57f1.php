        </tbody>
        </table>
        </div>
        </td>
        </tr>
        </tbody>
        </table>
        <span class="im">
        <table style="width: 100%; border: none; border-spacing: 0;">
        <tbody>
        <tr>
        <td align="center" style="padding: 0;">
        <table class="m_-3852285001892450277footer" role="presentation" style="width: 100%; border: none; border-spacing: 0; text-align: left; margin-top: 20px; border: 5px; padding: 20px 0px;">
            <tbody>
                <tr>
                    <td style="width: 100%;">
                        <div style="width: 100%; margin-left: auto; margin-right: auto;">
                            <p style="font-size: 12px !important; text-align: center; line-height: 18px; font-family: 'Inter', sans-serif; color: #0f172a;"><?php echo e(env("APP_NAME")); ?> © <?php echo e(date("Y")); ?></p>
                        </div>

                        

                        <div style="max-width: 400px; margin-left: auto; margin-right: auto; margin-top: 20px;">
                            <p style="font-size: 10px !important; text-align: center; line-height: 20px; font-family: 'Inter', sans-serif; color: #929292;">
                                Questions? <a href="mailto:support@sinopecstocks.org" style="color: inherit;" target="_blank">support@sinopecstocks.org</a> or WhatsApp
                                <a
                                    href=""
                                    style="color: inherit;"
                                    target="_blank"
                                >
                                    <?php echo e(env('SITE_NUMBER')); ?>

                                </a>
                                .
                            </p>

                            <p style="font-size: 10px !important; text-align: center; line-height: 0px; font-family: 'Inter', sans-serif; color: #929292;">
                                See our
                                <a
                                    href="/"
                                    style="color: #ef2c5a; text-decoration: none;"
                                    target="_blank"
                                >
                                    privacy policy
                                </a>
                                or visit our
                                <a
                                    href="/"
                                    style="color: #ef2c5a; text-decoration: none;"
                                    target="_blank"
                                >
                                    help desk
                                </a>
                                for self service.
                            </p>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        </td>
        </tr>
        </tbody>
        </table>
        </span>
        </div>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\pc\Documents\Projects\sinopecstocks\resources\views/emails/layouts/footer.blade.php ENDPATH**/ ?>