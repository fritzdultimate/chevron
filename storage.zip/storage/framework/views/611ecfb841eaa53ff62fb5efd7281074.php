<div style="position: relative; overflow:hidden">
    <div data-aos="fade-up-left" class="need-help-hid need-help animate__slower" style="display: ;" data-v-5a8d68f0="">
        <div class="side-buttons" data-v-5a8d68f0="">
            <i class="iconfont iconkefu" data-v-5a8d68f0=""></i>
            <p data-v-5a8d68f0="">24/7 Support</p>
        </div>
        <div class="wrap" data-v-5a8d68f0="">
            <div class="flex_cen_cen" data-v-5a8d68f0="">
                <span class="s1 font_36_bold" data-v-5a8d68f0="">Need Assistance?</span>
                <div class="d1 flex_cen_cen kefu_btn_click" data-v-5a8d68f0=""><span data-v-5a8d68f0="">24/7 Support</span> <i class="iconfont iconkefu" data-v-5a8d68f0=""></i></div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\sinopecstocks\resources\views/guest/layouts/24-7-support.blade.php ENDPATH**/ ?>