<?php if($errors->any()): ?>
    <div class="alert alert-danger">
            <?php echo e($errors->all()[0]); ?>

    </div>
<?php elseif(session('error')): ?>
    <div class="alert alert-danger">
        <span class="alert-text">
            <?php echo e(session('error')); ?>

        </span>
    </div>
<?php elseif(session('success')): ?>
    <div class="alert alert-success">
        <span class="alert-text">
            <?php echo e(session('success')); ?>

        </span>
    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\chevron\resources\views/admin/layouts/errors.blade.php ENDPATH**/ ?>