<div id="wrapper" class="foot-bg">
    <div class="wrap">
        <div class="foot">
            <div class="foot-left">
                <p> Address: Chaoyangmen North Street, Chaoyang District Beijing's Chain</p>
                <br><br>
                <span><b>©Copyright 2024 <?php echo e(env('SITE_NAME ')); ?>.</b></span>
            </div>
            
            <div class="foot-menu">
                <ul>
                    <li><a href="/limitation-of-liability">Limitation of liability</a></li>
                    <li><a href="/contact-us">Contact</a></li>
                    <li><a href="/help">Help</a></li>
                    <li><a href="privacy">Privacy</a></li>
                    <li><a href="/">Home</a></li>
                </ul>
                
                <div class="pay">
                    <img src="<?php echo e(asset('images/payment.png')); ?>">
                </div>
            </div>
            
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\chevron\resources\views/visitor/layouts/footer.blade.php ENDPATH**/ ?>